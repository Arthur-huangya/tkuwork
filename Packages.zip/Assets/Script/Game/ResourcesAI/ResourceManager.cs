using UnityEngine;
using TMPro;  // 引入 TextMeshPro 命名空間

public class ResourceManager : MonoBehaviour
{
    // 用來顯示蘑菇和木材數量的 UI 元件
    public TextMeshProUGUI mushroomCountText;  // 顯示蘑菇數量
    public TextMeshProUGUI woodCountText;      // 顯示木材數量

    // 蘑菇和木材的數量
    private int mushroomCount = 0;
    private int woodCount = 0;

    void Start()
    {
        // 初始化 UI
        UpdateUI();
    }

    // 當玩家拾取蘑菇
    public void AddMushroom(int amount)
    {
        mushroomCount += amount;
        UpdateUI();  // 更新 UI 顯示
    }

    // 當玩家拾取木材
    public void AddWood(int amount)
    {
        woodCount += amount;
        UpdateUI();  // 更新 UI 顯示
    }

    // 更新 UI 顯示
    void UpdateUI()
    {
        // 更新文本顯示蘑菇和木材的數量
        mushroomCountText.text =  mushroomCount.ToString();
        woodCountText.text =  woodCount.ToString();
    }
}
