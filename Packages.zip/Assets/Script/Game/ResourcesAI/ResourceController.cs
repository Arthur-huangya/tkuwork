using UnityEngine;
using TMPro;  // 引入 TextMeshPro 命名空間

public class ResourceController : MonoBehaviour
{
    public GameObject targetObject; // 目標物件（例如 Player）
    private Inventory inventory;    // 參考 Inventory 物件
    private ResourceManager resourceManager; // 參考 ResourceManager 來更新 UI

    private void Start()
    {
        // 確保物件上有 Inventory 組件
        inventory = FindObjectOfType<Inventory>();

        // 確保物件上有 ResourceManager 組件
        resourceManager = FindObjectOfType<ResourceManager>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // 檢查碰到的物件是否是目標物件（例如 Player）
        if (other.gameObject == targetObject)
        {
            string itemName = gameObject.name.Replace("(Clone)", "");
            // 顯示物品名稱
            Debug.Log("拾取了資源: " + gameObject.name);

            // 更新背包中的物品數量
            inventory.AddItem(gameObject.name, 1); // 使用 gameObject.name 來標識物品

            // 顯示當前物品的總數量
            int currentQuantity = inventory.GetItemCount(gameObject.name);
            Debug.Log($"{gameObject.name} 的當前數量: {currentQuantity}");

            // 根據物品名稱更新 UI
            if (gameObject.name == "mushroom(Clone)")
            {
                resourceManager.AddMushroom(1);  // 增加蘑菇數量
            }
            else if (gameObject.name == "wood(Clone)")
            {
                resourceManager.AddWood(1);  // 增加木材數量
            }

            // 銷毀資源物件
            Destroy(gameObject);
        }
    }
}
