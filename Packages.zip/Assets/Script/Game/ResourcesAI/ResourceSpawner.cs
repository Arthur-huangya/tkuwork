using UnityEngine;

public class ResourceSpawner : MonoBehaviour
{
    public GameObject[] resourcePrefabs; // 資源 Prefab 陣列（木材、蘑菇）
    public float spawnInterval = 3f; // 刷新間隔
    public Camera mainCamera; // Main Camera
    public Vector2 spawnAreaMin = new Vector2(-4.5f, -4.5f); // 刷新區域最小值 (x, y)
    public Vector2 spawnAreaMax = new Vector2(4.5f, 4.5f);   // 刷新區域最大值 (x, y)
    void Start()
    {
        InvokeRepeating("SpawnResource", 0f, spawnInterval);
    }

    void SpawnResource()
    {
        // 獲取 Main Camera 的視口範圍
        //float cameraHeight = 2f * mainCamera.orthographicSize;
        //float cameraWidth = cameraHeight * mainCamera.aspect;

        // 隨機生成位置
       Vector3 spawnPosition = new Vector3(
            Random.Range(spawnAreaMin.x, spawnAreaMax.x), // X 軸範圍
            Random.Range(spawnAreaMin.y, spawnAreaMax.y), // Y 軸範圍
            0 // Z 軸固定為 0
        );

        // 隨機選擇一個資源 Prefab
        GameObject resourcePrefab = resourcePrefabs[Random.Range(0, resourcePrefabs.Length)];

        // 生成資源
        Instantiate(resourcePrefab, spawnPosition, Quaternion.identity);
    }
}