using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 2f; // 每秒 2 格移動速度

    void Update()
    {
        // 取得玩家輸入
        float moveX = Input.GetAxis("Horizontal"); // A/D 或 左右鍵
        float moveY = Input.GetAxis("Vertical");   // W/S 或 上下鍵

        // 移動角色
        Vector3 movement = new Vector3(moveX, moveY, 0f).normalized;
        transform.position += movement * moveSpeed * Time.deltaTime;
    }
}

