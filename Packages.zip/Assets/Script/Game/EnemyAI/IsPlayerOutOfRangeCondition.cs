using UnityEngine;

public class IsPlayerOutOfRangeCondition : BehaviorNode
{
    private Transform enemy;
    private Transform player;
    private float range;

    public IsPlayerOutOfRangeCondition(Transform enemy, Transform player, float range)
    {
        this.enemy = enemy;
        this.player = player;
        this.range = range;
    }

    public override bool Execute()
    {
        return Vector3.Distance(enemy.position, player.position) > range;
    }
}
