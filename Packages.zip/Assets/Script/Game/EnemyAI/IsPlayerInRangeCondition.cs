using UnityEngine;

public class IsPlayerInRangeCondition : BehaviorNode
{
    private Transform enemy;
    private Transform player;
    private float range;

    public IsPlayerInRangeCondition(Transform enemy, Transform player, float range)
    {
        this.enemy = enemy;
        this.player = player;
        this.range = range;
    }

    public override bool Execute()
    {
        return Vector3.Distance(enemy.position, player.position) <= range;
    }
}
