using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Transform player;         // 玩家的位置
    public float patrolSpeed = 0.5f; // 巡邏速度
    public float chaseSpeed = 1f;    // 追擊速度
    public float detectionRange = 3f; // 檢測距離
 public GameObject targetObject; // 目標物件（例如 Player）
    private BehaviorNode rootNode;
    private Renderer enemyRenderer;      
    private Material enemyMaterial;  

    void Start()
    {
        // 獲取 Renderer 來修改顏色
        enemyRenderer = GetComponent<Renderer>();

        // 創建並分配材質，這樣每個敵人都有自己的材質實例
        enemyMaterial = new Material(enemyRenderer.sharedMaterial);
        enemyRenderer.material = enemyMaterial;

        // 設置初始顏色為白色
        SetEnemyColor(Color.white);

        // 建立行為樹
        rootNode = new SelectorNode();

        // 巡邏行為
        var patrolSequence = new SequenceNode();
        patrolSequence.AddChild(new IsPlayerOutOfRangeCondition(transform, player, detectionRange));
        patrolSequence.AddChild(new PatrolAction(transform, patrolSpeed));

        // 追擊行為
        var chaseSequence = new SequenceNode();
        chaseSequence.AddChild(new IsPlayerInRangeCondition(transform, player, detectionRange));
        chaseSequence.AddChild(new ChaseAction(transform, player, chaseSpeed));

        // 加入到根節點
        ((SelectorNode)rootNode).AddChild(chaseSequence);
        ((SelectorNode)rootNode).AddChild(patrolSequence);
    }

    void Update()
    {
        // 執行行為樹
        rootNode.Execute();

        // 檢查是否進入攻擊狀態並變色
    
    
        if (Vector3.Distance(transform.position, player.position) <= detectionRange)
        {
            SetEnemyColor(Color.yellow); // 進入攻擊狀態，顏色變黃
        }
        else
        {
            SetEnemyColor(Color.white); // 進入巡邏狀態，顏色變白
        }
    }
private void OnTriggerEnter2D(Collider2D other)
    {
        // 檢查碰到的物件是否是目標物件
        if (other.gameObject == targetObject)
        {
            Debug.Log("被擊中! " );
            
        }
    }

    
    // 設置敵人的顏色
    private void SetEnemyColor(Color color)
    {
        if (enemyMaterial != null)
        {
            enemyMaterial.color = color;
        }
    }
}
