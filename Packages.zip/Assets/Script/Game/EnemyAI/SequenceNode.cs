using System.Collections.Generic;

public class SequenceNode : BehaviorNode
{
    private List<BehaviorNode> childNodes = new List<BehaviorNode>();

    public void AddChild(BehaviorNode child)
    {
        childNodes.Add(child);
    }

    public override bool Execute()
    {
        foreach (var child in childNodes)
        {
            if (!child.Execute())
            {
                return false; // 任一子節點失敗則返回失敗
            }
        }
        return true; // 全部子節點成功則返回成功
    }
}
