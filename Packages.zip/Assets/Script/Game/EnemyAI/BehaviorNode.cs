public abstract class BehaviorNode
{
    public abstract bool Execute(); // 所有節點需實現此方法
}

