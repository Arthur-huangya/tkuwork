using UnityEngine;

public class ChaseAction : BehaviorNode
{
    private Transform enemy;
    private Transform player;
    private float chaseSpeed;

    public ChaseAction(Transform enemy, Transform player, float chaseSpeed)
    {
        this.enemy = enemy;
        this.player = player;
        this.chaseSpeed = chaseSpeed;
    }

    public override bool Execute()
    {
        // 向玩家位置移動
        enemy.position = Vector3.MoveTowards(enemy.position, player.position, chaseSpeed * Time.deltaTime);
        return true; // 追擊永遠返回成功
    }
}
