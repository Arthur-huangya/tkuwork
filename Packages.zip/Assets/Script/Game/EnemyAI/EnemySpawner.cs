using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab;        // 預製敵人物件
    public float spawnInterval = 10f;     // 生成間隔時間
    public Vector3 spawnPosition = Vector3.zero; // 生成位置，這裡設置為 (0, 0)

    private void Start()
    {
        // 開始定期在(0, 0)生成敵人
        InvokeRepeating("SpawnEnemy", 0f, spawnInterval);
    }

    void SpawnEnemy()
    {
        // 確認是否調用了生成方法
        Debug.Log("生成敵人");

        // 在指定的座標生成敵人
        Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
    }
}
