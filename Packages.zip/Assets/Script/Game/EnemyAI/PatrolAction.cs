using UnityEngine;

public class PatrolAction : BehaviorNode
{
    private Transform enemy;
    private float patrolSpeed;
    private float moveDistance = 3f; // 每次移動 3 格
    private float moveTime = 0f; // 移動計時器
    private Vector3 targetPosition; // 目標位置
    private bool isMoving = false; // 是否正在移動

    public PatrolAction(Transform enemy, float patrolSpeed)
    {
        this.enemy = enemy;
        this.patrolSpeed = patrolSpeed;
    }

    public override bool Execute()
    {
        if (isMoving)
        {
            // 持續移動至目標位置
            enemy.position = Vector3.MoveTowards(enemy.position, targetPosition, patrolSpeed * Time.deltaTime);

            // 如果已經達到目標位置，則停止移動並設置為等待
            if (Vector3.Distance(enemy.position, targetPosition) <= 0.1f)
            {
                isMoving = false;
                moveTime = Time.time + 1f; // 設定等待時間為 1 秒
            }
        }
        else
        {
            // 檢查是否在等待時間結束
            if (Time.time > moveTime)
            {
                // 設定隨機方向並移動 3 格
                targetPosition = enemy.position + new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0f).normalized * moveDistance;
                isMoving = true;
            }
        }

        // 巡邏永遠返回成功
        return true;
    }
}
