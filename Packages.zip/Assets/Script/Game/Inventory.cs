using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    // 用來存儲物品和數量
    public Dictionary<string, int> items = new Dictionary<string, int>();

    // 添加物品
    public void AddItem(string itemName, int quantity)
    {
        if (items.ContainsKey(itemName))
        {
            items[itemName] += quantity;  // 如果物品已經有了，增加數量
        }
        else
        {
            items.Add(itemName, quantity);  // 否則，添加新物品
        }
    }

    // 獲取物品數量
    public int GetItemCount(string itemName)
    {
        if (items.ContainsKey(itemName))
        {
            return items[itemName];  // 返回物品數量
        }
        return 0;  // 如果沒有這個物品，返回0
    }
}
