using UnityEngine;
using TMPro;

public class CompanionInteraction : MonoBehaviour
{
    public GameObject dialoguePanel; // 對話框 Panel
    public TextMeshProUGUI dialogueText; // TextMeshPro 文字元件
    public string[] dialogues; // 對話內容陣列
    public GameObject targetObject; // 目標物件（例如 Player）
    private int currentDialogueIndex = 0;
    private bool isTouchingPlayer = false; // 是否正在接觸 Player

    private void Update()
    {
        // 如果正在接觸 Player 且按下 F 鍵
        if (isTouchingPlayer && Input.GetKeyDown(KeyCode.F))
        {
            ShowDialoguePanel(); // 顯示對話框
        }

        // 如果對話框顯示中且按下 G 鍵
        if (dialoguePanel.activeSelf && Input.GetKeyDown(KeyCode.G))
        {
            HideDialoguePanel(); // 隱藏對話框
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // 檢查碰到的物件是否是目標物件
        if (other.gameObject == targetObject)
        {
            isTouchingPlayer = true;
            Debug.Log("玩家接觸到村民");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        // 檢查離開的物件是否是目標物件
        if (other.gameObject == targetObject)
        {
            isTouchingPlayer = false;
            HideDialoguePanel(); // 玩家離開時隱藏對話框
            Debug.Log("玩家離開村民");
        }
    }

    private void ShowDialoguePanel()
    {
        // 顯示對話框
        dialoguePanel.SetActive(true);

        // 顯示下一句對話
        if (dialogues.Length > 0)
        {
            dialogueText.text = dialogues[currentDialogueIndex];
            currentDialogueIndex = (currentDialogueIndex + 1) % dialogues.Length;
        }
    }

    private void HideDialoguePanel()
    {
        // 隱藏對話框
        dialoguePanel.SetActive(false);
    }
}