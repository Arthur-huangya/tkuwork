using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class InventoryUIController : MonoBehaviour
{
    public GameObject inventoryUI; // 指向背包 UI
    public GameObject itemSlotPrefab;  // 用來保存物品格子的預製物件
    public Transform gridLayoutContainer;  // Grid Layout Group 容器

    void Start()
    {
        inventoryUI.SetActive(false); // 確保遊戲開始時 UI 是關閉的
    }

    // 切換背包顯示
    public void ToggleInventory()
    {
        inventoryUI.SetActive(!inventoryUI.activeSelf);

        // 當背包顯示時更新 UI
        if (inventoryUI.activeSelf)
        {
            UpdateInventoryUI();  // 更新格子顯示
        }
    }

    // 更新背包中的物品格子顯示
    public void UpdateInventoryUI()
    {
        // 清空現有的格子
        foreach (Transform child in gridLayoutContainer)
        {
            Destroy(child.gameObject);
        }

        // 生成10個格子作為測試（不依賴物品數據）
        for (int i = 0; i < 20; i++)
        {
            // 創建一個新的物品格子
            GameObject itemSlot = Instantiate(itemSlotPrefab, gridLayoutContainer);
            
            // (可選) 打印出來確認格子創建了多少次
            Debug.Log("ItemSlot " + i + " created");
        }
    }
}
