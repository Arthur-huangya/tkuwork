using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum E_AI_State 
{
    ///<summary>
    ///</summary>
    Sleep,
    ///<summary>
    ///</summary>
    Patrol,
    ///<summary>
    ///</summary>
    Chat,
    ///<summary>
    ///</summary>
    Run,
    ///<summary>
    ///</summary>
    Chase,
    ///<summary>
    ///</summary>
    Atk,
    ///<summary>
    ///</summary>
    Alertness,
}
