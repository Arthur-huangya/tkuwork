using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//有限狀態機類，主要用於管理各種狀態之間的切換
public class StateMachine 
{
    //存放狀態的容器//
    private Dictionary<E_AI_State, BaseState> stateDic = new Dictionary<E_AI_State, BaseState>();
    //當前狀態//
    private BaseState nowState;
    public IAIobj aiOBJ;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="aIobj"></param>
    public void Init(IAIobj aIobj)
    {
        this.aiOBJ = aiOBJ;
    }
    public void ChangeState(E_AI_State state)

    {
        if(nowState !=null)
        nowState.QuitState();

        if(stateDic.ContainsKey(state))
        {
            nowState = stateDic[state];
            nowState.EnterState();
        }
    }
    public void UpdateState()
    {
        if(nowState != null)
        nowState.UpdateState();
    }
}

