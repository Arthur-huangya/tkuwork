using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAIobj 
{
   public void Move(Vector3 dir0rPos);
   public void StopMove();

   public void Atk();
   public void ChangeAction(E_Action action);
}
