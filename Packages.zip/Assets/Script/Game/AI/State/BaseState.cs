using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//狀態基 所有狀態都繼承他//
public abstract class BaseState 
{
    
    protected StateMachine stateMachine;
    public void Init(StateMachine machine)
    {
        stateMachine = machine;
    }
    public virtual E_AI_State AIState
    {
        get;
    }
    public abstract void QuitState();

    public abstract void EnterState();
    
    public abstract void UpdateState();
}
