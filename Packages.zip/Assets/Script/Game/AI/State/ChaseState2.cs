using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChaseState : BaseState
{
    public override void EnterState()
   {
    throw new System.NotImplementedException();
   }
   public override void QuitState()
   {
    throw new System.NotImplementedException();
   }
   public override void UpdateState()
   {
    throw new System.NotImplementedException();
   }
}
