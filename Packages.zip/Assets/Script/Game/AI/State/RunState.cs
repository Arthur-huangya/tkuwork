using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunState : BaseState
{
    public override E_AI_State AIState => E_AI_State.Run;
    public override void EnterState()
   {
   
   }
   public override void QuitState()
   {
 
   }
   public override void UpdateState()
   {

   }
}
