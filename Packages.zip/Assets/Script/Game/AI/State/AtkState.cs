using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AtkState : BaseState
{
    
   
   public override void EnterState()
   {
    
   }
   public override void QuitState()
   {
   }
   public override void UpdateState()
   {
   }
}
