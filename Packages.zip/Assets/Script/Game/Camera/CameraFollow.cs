using UnityEngine;

public class CameraFollow: MonoBehaviour
{
    public Transform player; // 玩家的Transform组件
    public Vector2 offset; // 镜头与玩家的偏移量
    public float smoothSpeed = 0.125f; // 镜头跟随的平滑速度

    void LateUpdate()
    {
        // 计算镜头期望的位置，只改变x和y坐标
        Vector3 desiredPosition = new Vector3(player.position.x + offset.x, player.position.y + offset.y, transform.position.z);
        
        // 平滑过渡到期望的位置
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        
        // 设置镜头位置
        transform.position = smoothedPosition;
    }
}